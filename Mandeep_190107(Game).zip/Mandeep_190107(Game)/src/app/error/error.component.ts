import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';

import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {

    constructor(private gameService: GameService, private router: Router) { }

    /*
      NAvigation is used to link to the play.html page
    */
  ngOnInit() {
      setTimeout( () => {
        this.router.navigate(['/play']);     
      }, 20 )
    }
  }




