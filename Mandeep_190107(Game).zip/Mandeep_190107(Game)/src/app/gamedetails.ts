export interface GameDetails {
  gameId: number;
  gameName: string;
  gamePrice: number;

}
